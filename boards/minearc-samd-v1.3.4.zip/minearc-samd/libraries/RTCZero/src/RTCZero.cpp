/*
  RTC library for Arduino Zero.
  Copyright (c) 2015 Arduino LLC. All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

#include <time.h>

#include "RTCZero.h"

void RTCZero::begin(Period_Size period) {
  MCLK->APBAMASK.bit.RTC_ = 1; // enable RTC clock

  RTC->MODE1.CTRLA.bit.ENABLE = 0; // disable RTC
  while (!RTC->MODE1.SYNCBUSY.bit.ENABLE)
    ;

  RTC->MODE1.CTRLA.bit.MODE = RTC_MODE1_CTRLA_MODE_COUNT16_Val;
  RTC->MODE1.CTRLA.bit.PRESCALER = RTC_MODE1_CTRLA_PRESCALER_DIV32_Val;
  RTC->MODE1.INTENSET.bit.OVF = 1;
  RTC->MODE1.PER.bit.PER = period;
  while (!RTC->MODE1.SYNCBUSY.bit.PER)
    ;

  RTC->MODE1.CTRLA.bit.ENABLE = 1;
  while (!RTC->MODE1.SYNCBUSY.bit.ENABLE)
    ;

  NVIC_EnableIRQ(RTC_IRQn); // enable RTC interrupt
  NVIC_SetPriority(RTC_IRQn, 0x00);
}

void RTCZero::attachInterrupt(voidFuncPtr callback) { _callback = callback; }

void RTCZero::standbyMode() {
  PM->SLEEPCFG.bit.SLEEPMODE = PM_SLEEPCFG_SLEEPMODE_STANDBY_Val;
  __DSB();
  __WFI();
}