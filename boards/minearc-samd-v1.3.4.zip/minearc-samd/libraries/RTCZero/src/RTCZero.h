/*
  RTC library for Arduino Zero.
  Copyright (c) 2015 Arduino LLC. All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef RTC_ZERO_H
#define RTC_ZERO_H

#include "Arduino.h"

class RTCZero {
public:
  enum Period_Size : uint16_t {
    PERIOD_8 = 8,        // 8 clock cycles
    PERIOD_16 = 16,      // 16 clock cycles
    PERIOD_32 = 32,      // 32 clock cycles
    PERIOD_64 = 64,      // 64 clock cycles
    PERIOD_128 = 128,    // 128 clock cycles
    PERIOD_256 = 256,    // 256 clock cycles
    PERIOD_512 = 512,    // 512 clock cycles
    PERIOD_1024 = 1024,  // 1024 clock cycles
    PERIOD_2048 = 2048,  // 2048 clock cycles
    PERIOD_4096 = 4096,  // 4096 clock cycles
    PERIOD_8192 = 8192,  // 8192 clock cycles
    PERIOD_16384 = 16384 // 16384 clock cycles
  };

  void begin(Period_Size);
  void attachInterrupt(voidFuncPtr);
  void standbyMode();

private:
  voidFuncPtr _callback = NULL;
};

#endif // RTC_ZERO_H