#!/bin/bash -ex
BOARD_ID=pathfinder NAME=pathfinder mingw32-make clean all

echo Done building bootloaders!